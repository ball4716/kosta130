package com.return3.hash_model;

import java.util.HashMap;
import java.util.Iterator;

public class NumberHashmapModel {
	public HashMap<String, String> number_map;
	public NumberHashmapModel() {
		number_map = new HashMap<>();
		
		number_map.put("lee", "010-7157-8550");
		number_map.put("oh", "010-3952-5797");
		number_map.put("park", "010-9040-4886");
		number_map.put("kim", "010-7722-4716");
		number_map.put("kim1", "010-6543-9876");
	}
}
