package com.return3.hash_view;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class ListNumberView extends JFrame{
	public JTextField search_field;
	public JList<String> number_list;
	public JScrollPane list_scroll;
	Image list_bg;
	
	public ListNumberView() {
		search_field = new JTextField(){
			@Override
			public void setBorder(Border border){
				//�׵θ� ���ֱ�
			}
		};
		search_field.setBounds(20, 108, 500, 30);
		search_field.setFont(new Font("����", Font.PLAIN, 20));
		search_field.setHorizontalAlignment(JTextField.CENTER);
		
		number_list = new JList<>();
		list_scroll = new JScrollPane();
		list_scroll.add(number_list);
		list_scroll.setBounds(0, 155, 540, 735);
		
		list_bg = new ImageIcon("image/hash/number003.jpg").getImage();
		
		//��� ����
		JPanel background = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				g.drawImage(list_bg, 0, 0, null);
				setOpaque(false);// �׸� ǥ�� ����
				super.paintComponent(g);
			}
		};
		
		background.add(search_field);
		background.add(list_scroll);
		background.setLayout(null);
		
		//�信 background���̱�
		setContentPane(background);
		setSize(560, 1015);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new ListNumberView();
	}
}
