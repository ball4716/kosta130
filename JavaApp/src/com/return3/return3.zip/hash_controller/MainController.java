package com.return3.hash_controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.return3.hash_view.MainNumberView;

public class MainController implements ActionListener{
	MainNumberView number_view;
	
	public MainController() {
		number_view = new MainNumberView();
		
		eventUp();
	}
	
	public void eventUp(){
		//����ȭ�� ��ư��
		for (int i = 0; i < number_view.number_button.length; i++) {
			number_view.number_button[i].addActionListener(this);
		}
		number_view.add_button.addActionListener(this);
		number_view.del_button.addActionListener(this);
		number_view.bot_button.addActionListener(this);
		
		//�˾� ��ư��
		number_view.new_btn.addActionListener(this);
		number_view.update_btn.addActionListener(this);
		number_view.cancel_btn.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj==number_view.number_button[0]){//1��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"1");
		}else if(obj==number_view.number_button[1]){//2��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"2");
		}else if(obj==number_view.number_button[2]){//3��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"3");
		}else if(obj==number_view.number_button[3]){//4��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"4");
		}else if(obj==number_view.number_button[4]){//5��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"5");
		}else if(obj==number_view.number_button[5]){//6��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"6");
		}else if(obj==number_view.number_button[6]){//7��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"7");
		}else if(obj==number_view.number_button[7]){//8��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"8");
		}else if(obj==number_view.number_button[8]){//9��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"9");
		}else if(obj==number_view.number_button[9]){//0��Ŭ��
			addHipen();
			number_view.number_field.setText(number_view.number_field.getText()+"0");
		}else if(obj==number_view.add_button){//�߰�
			if(number_view.number_field.getText().length()==0)
				return;
			number_view.add_pnl.setVisible(true);
			//��ư ��Ȱ��ȭ
			for (int i = 0; i < number_view.number_button.length; i++) {
				number_view.number_button[i].setEnabled(false);
			}
			number_view.add_button.setEnabled(false);
			number_view.del_button.setEnabled(false);
			number_view.bot_button.setEnabled(false);
		}else if(obj==number_view.del_button){//�ؽ�Ʈ�ʵ� �����
			if(number_view.number_field.getText().length()==0)
				return;
			delHipen();
			number_view.number_field.setText(number_view.number_field.getText().substring(0, number_view.number_field.getText().length()-1));
		}else if(obj==number_view.bot_button){//��ȭ��ȣ�η� �Ѿ��
			
		}else if(obj==number_view.new_btn){//��ȭ��ȣ ���� �߰�
			
		}else if(obj==number_view.update_btn){//��ȭ��ȣ ����
			
		}else if(obj==number_view.cancel_btn){//���
			number_view.add_pnl.setVisible(false);
			//��ư Ȱ��ȭ
			for (int i = 0; i < number_view.number_button.length; i++) {
				number_view.number_button[i].setEnabled(true);
			}
			number_view.add_button.setEnabled(true);
			number_view.del_button.setEnabled(true);
			number_view.bot_button.setEnabled(true);
		}
	}
	
	public void addHipen(){
		if(number_view.number_field.getText().length()==3 || number_view.number_field.getText().length()==8){
			number_view.number_field.setText(number_view.number_field.getText()+"-");
		}
	}
	
	public void delHipen(){
		if(number_view.number_field.getText().length()==4 || number_view.number_field.getText().length()==9){
			number_view.number_field.setText(number_view.number_field.getText().substring(0, number_view.number_field.getText().length()-1));
		}
	}
	
	public static void main(String[] args) {
		new MainController();
	}

}