package com.return3.hash_view;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class AddNumberView extends JFrame{
	JTextField name_field;
	Image hangeul_bg, english_bg;
	JPanel background_han, background_eng;

	public AddNumberView() {
		name_field = new JTextField(20) {
			@Override
			public void setBorder(Border border) {
				// �׵θ� ���ֱ�
			}
		};
		name_field.setBounds(80, 100, 200, 30);
		name_field.setFont(new Font("����", Font.PLAIN, 50));

		hangeul_bg = new ImageIcon("image/hash/add_new_hangeul.jpg").getImage();
		english_bg = new ImageIcon("image/hash/add_new_english.jpg").getImage();

		// ��� ����
		background_han = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(hangeul_bg, 0, 0, null);
				setOpaque(false);// �׸� ǥ�� ����
				super.paintComponent(g);
			}
		};

		// ��� ����
		background_eng = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(english_bg, 0, 0, null);
				setOpaque(false);// �׸� ǥ�� ����
				super.paintComponent(g);
			}
		};
		
		background_han.setLayout(null);
		background_han.setVisible(true);
		
		background_eng.setLayout(null);
		background_eng.setVisible(true);
		
		setContentPane(background_eng);
		setContentPane(background_han);
		setSize(560,1010);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new AddNumberView();
	}
}
