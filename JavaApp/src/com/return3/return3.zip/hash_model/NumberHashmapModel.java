package com.return3.hash_model;

import java.util.HashMap;

public class NumberHashmapModel {
	public HashMap<String, String> number_map;
	public NumberHashmapModel() {
		number_map = new HashMap<>();
	}
}
